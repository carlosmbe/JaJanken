import CreateML
import Foundation

let path = "/Users/carlosmbendera/Developer/Personal Projects/GitHub/JaJanken/Back Up Model/Dataset"
let url = URL(fileURLWithPath: path)

guard let data = try? MLDataTable(contentsOf: url) else {
    fatalError("Error loading dataset")
}

let (trainingData, validationData) = data.randomSplit(by: 0.8, seed: 42)

let modelConfig = MLImageClassifier.ModelParameters(featureExtractor: .mobileNetV2(),
                                                     validation: .data(validationData),
                                                     maxIterations: 30,
                                                     augmentationOptions: [.flip, .rotation, .crop])

let classifier = try MLImageClassifier(trainingData: trainingData,
                                       parameters: modelConfig)

let evaluationMetrics = classifier.evaluation(on: validationData)
let evaluationAccuracy = (1.0 - evaluationMetrics.classificationError) * 100
print("Model Accuracy: \(evaluationAccuracy)%")

let metadata = MLModelMetadata(author: "Carlos Mbendera, Chanu Lee",
                               shortDescription: "HackKU 23 ASL Hand Gesture Recognition",
                               version: "1.0")

try! classifier.write(to: URL(fileURLWithPath: "/Users/carlosmbendera/Developer/Personal Projects/GitHub/JaJanken/Back Up Model/ASLClassifier.mlmodel"), metadata: metadata)
